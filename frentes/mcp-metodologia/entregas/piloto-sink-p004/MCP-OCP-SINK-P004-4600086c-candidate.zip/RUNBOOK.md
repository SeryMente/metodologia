# MCP-OCP SINK:P004 - paquete piloto candidato

**Estado:** CANDIDATE / NOT ACCEPTED / NOT INSTALLED
**Build source:** SeryMente/metodologia, rama feat/mcp-ocp-p004-reconciled-20261111-7ab0c555, commit 4600086c492582c5d854145db64097310ac73686.
**Base de main:** 1867af0c69f250aaee2b35b585eec8b74827b69c.
**Revisión:** PR #28, OPEN / DRAFT / NOT MERGED.
**DUG:** Samantha v388 / NX-388m; commit 3ba8e7373324c3dfbdf6d5d26f9da31e2418e71c; Git blob 4db0ebadfd1e48b2bdec9236ba7f344921e4a865.

## Runtime prerequisites

- Windows x64.
- Microsoft.NETCore.App 10.0.x x64 instalado en el destino; el SDK no es necesario para ejecutar.
- Un checkout íntegro de SeryMente/metodologia que contenga la fuente DUG fijada por commit/blob.
- Cliente MCP configurado para iniciar server/OcpMcp.exe serve --repo-root <ruta-absoluta-del-checkout> por STDIO.
- STDOUT queda exclusivamente para JSON-RPC; diagnósticos y eventos se emiten por STDERR.
- No se crea listener de red. La única herramienta expuesta es sink_principle; este piloto admite únicamente P004.

## Build y pruebas locales ligados al commit

- SDK .NET 10.0.403, PowerShell 7.4.22, Windows x64.
- Restore de los dos proyectos de pruebas: PASS.
- Build servidor/monitor y ambos proyectos de tests: PASS, 0 warnings / 0 errors.
- Contrato P004: 18/18 PASS.
- Monitor/readiness: 23/23 PASS.
- Smoke STDIO/EOF: initialize, tools/list, tools/call(P004), tres respuestas JSON-RPC y evento SINK_READ_SUCCESS por STDERR: PASS.
- El SDK se usó desde una carpeta temporal aislada; no se instaló a nivel de máquina ni se alteró PATH persistente.

## Verificación del paquete

Manifest y SHA256SUMS.txt acompañan el ZIP fuera del archivo. Verificar la suma del ZIP antes de extraerlo; después cotejar tamaño/SHA-256 de cada archivo contra manifest.json. El recibo de validación acompaña el manifiesto. La extracción y el smoke se ejecutan sobre el binario exacto empaquetado.

## Gates de instalación y aceptación

MCP-OCP no instala ni configura un root persistente desde este paquete. EP-TASK-003 debe pasar primero sus gates de host/workspace/almacenamiento protegido; EP-TASK-005 es responsable de recepción, extracción, read-back e instalación. REGISTER <SID> es interactivo y requiere el operador presente; nunca automatizarlo ni enviar SID por chat.

Gobernanza conserva la aceptación IPZ -> RDC -> STDIO -> respuesta visible desde contexto IPZ. El smoke local y esta validación no constituyen esa aceptación.

MCP-NORMATIVO=DESACTIVADO. FOL1 permanece preparado/inactivo.